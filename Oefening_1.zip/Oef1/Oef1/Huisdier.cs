﻿namespace Oef1
{
    internal class Huisdier
    {
        private string Naam { get; set; }
        private int Leeftijd { get; set; }

        public Huisdier(string naam, int leeftijd)
        {
            Naam = naam;
            Leeftijd = leeftijd;
        }
        public override string ToString()
        {
            return " " + Naam +", " + Leeftijd;
        }


       
    }
}
