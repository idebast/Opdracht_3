﻿namespace Oef1
{
    partial class ListsManager
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.integersInput = new System.Windows.Forms.TextBox();
            this.persoonInput = new System.Windows.Forms.TextBox();
            this.stringsInput = new System.Windows.Forms.TextBox();
            this.integersToevoegen = new System.Windows.Forms.Button();
            this.verwijderenIntegers = new System.Windows.Forms.Button();
            this.LeegmakenIntegers = new System.Windows.Forms.Button();
            this.showListIntegers = new System.Windows.Forms.Button();
            this.SearchInteger = new System.Windows.Forms.Button();
            this.CopyListInteger = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toevoegenStrings = new System.Windows.Forms.Button();
            this.verwijderenStrings = new System.Windows.Forms.Button();
            this.leegmakenStrings = new System.Windows.Forms.Button();
            this.showListStrings = new System.Windows.Forms.Button();
            this.SearchStrings = new System.Windows.Forms.Button();
            this.copyStrings = new System.Windows.Forms.Button();
            this.toevoegenPersoon = new System.Windows.Forms.Button();
            this.LeegmakenPersoon = new System.Windows.Forms.Button();
            this.verwijderenPersoon = new System.Windows.Forms.Button();
            this.showPersonen = new System.Windows.Forms.Button();
            this.searchPersoon = new System.Windows.Forms.Button();
            this.copyPersoon = new System.Windows.Forms.Button();
            this.inputleeftijd = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // integersInput
            // 
            this.integersInput.Location = new System.Drawing.Point(143, 127);
            this.integersInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.integersInput.Name = "integersInput";
            this.integersInput.Size = new System.Drawing.Size(146, 23);
            this.integersInput.TabIndex = 0;
            // 
            // persoonInput
            // 
            this.persoonInput.Location = new System.Drawing.Point(649, 127);
            this.persoonInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.persoonInput.Name = "persoonInput";
            this.persoonInput.Size = new System.Drawing.Size(148, 23);
            this.persoonInput.TabIndex = 1;
            // 
            // stringsInput
            // 
            this.stringsInput.Location = new System.Drawing.Point(410, 127);
            this.stringsInput.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.stringsInput.Name = "stringsInput";
            this.stringsInput.Size = new System.Drawing.Size(154, 23);
            this.stringsInput.TabIndex = 2;
            // 
            // integersToevoegen
            // 
            this.integersToevoegen.Location = new System.Drawing.Point(165, 162);
            this.integersToevoegen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.integersToevoegen.Name = "integersToevoegen";
            this.integersToevoegen.Size = new System.Drawing.Size(101, 22);
            this.integersToevoegen.TabIndex = 3;
            this.integersToevoegen.Text = "Toevoegen";
            this.integersToevoegen.UseVisualStyleBackColor = true;
            this.integersToevoegen.Click += new System.EventHandler(this.integersToevoegen_Click);
            // 
            // verwijderenIntegers
            // 
            this.verwijderenIntegers.Location = new System.Drawing.Point(165, 200);
            this.verwijderenIntegers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.verwijderenIntegers.Name = "verwijderenIntegers";
            this.verwijderenIntegers.Size = new System.Drawing.Size(101, 22);
            this.verwijderenIntegers.TabIndex = 4;
            this.verwijderenIntegers.Text = "Verwijderen";
            this.verwijderenIntegers.UseVisualStyleBackColor = true;
            this.verwijderenIntegers.Click += new System.EventHandler(this.verwijderenIntegers_Click);
            // 
            // LeegmakenIntegers
            // 
            this.LeegmakenIntegers.Location = new System.Drawing.Point(165, 235);
            this.LeegmakenIntegers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LeegmakenIntegers.Name = "LeegmakenIntegers";
            this.LeegmakenIntegers.Size = new System.Drawing.Size(101, 22);
            this.LeegmakenIntegers.TabIndex = 5;
            this.LeegmakenIntegers.Text = "Leegmaken";
            this.LeegmakenIntegers.UseVisualStyleBackColor = true;
            this.LeegmakenIntegers.Click += new System.EventHandler(this.LeegmakenIntegers_Click);
            // 
            // showListIntegers
            // 
            this.showListIntegers.Location = new System.Drawing.Point(165, 268);
            this.showListIntegers.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.showListIntegers.Name = "showListIntegers";
            this.showListIntegers.Size = new System.Drawing.Size(103, 22);
            this.showListIntegers.TabIndex = 6;
            this.showListIntegers.Text = "Show List";
            this.showListIntegers.UseVisualStyleBackColor = true;
            this.showListIntegers.Click += new System.EventHandler(this.showListIntegers_Click);
            // 
            // SearchInteger
            // 
            this.SearchInteger.Location = new System.Drawing.Point(165, 302);
            this.SearchInteger.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SearchInteger.Name = "SearchInteger";
            this.SearchInteger.Size = new System.Drawing.Size(103, 22);
            this.SearchInteger.TabIndex = 7;
            this.SearchInteger.Text = "Search";
            this.SearchInteger.UseVisualStyleBackColor = true;
            this.SearchInteger.Click += new System.EventHandler(this.SearchInteger_Click);
            // 
            // CopyListInteger
            // 
            this.CopyListInteger.Location = new System.Drawing.Point(165, 338);
            this.CopyListInteger.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.CopyListInteger.Name = "CopyListInteger";
            this.CopyListInteger.Size = new System.Drawing.Size(101, 22);
            this.CopyListInteger.TabIndex = 8;
            this.CopyListInteger.Text = "Copy";
            this.CopyListInteger.UseVisualStyleBackColor = true;
            this.CopyListInteger.Click += new System.EventHandler(this.CopyListInteger_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(172, 98);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 15);
            this.label1.TabIndex = 9;
            this.label1.Text = "Stapel Integers";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(435, 98);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "Stapel van strings";
            // 
            // toevoegenStrings
            // 
            this.toevoegenStrings.Location = new System.Drawing.Point(435, 162);
            this.toevoegenStrings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.toevoegenStrings.Name = "toevoegenStrings";
            this.toevoegenStrings.Size = new System.Drawing.Size(107, 22);
            this.toevoegenStrings.TabIndex = 12;
            this.toevoegenStrings.Text = "Toevoegen";
            this.toevoegenStrings.UseVisualStyleBackColor = true;
            this.toevoegenStrings.Click += new System.EventHandler(this.toevoegenStrings_Click);
            // 
            // verwijderenStrings
            // 
            this.verwijderenStrings.Location = new System.Drawing.Point(435, 200);
            this.verwijderenStrings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.verwijderenStrings.Name = "verwijderenStrings";
            this.verwijderenStrings.Size = new System.Drawing.Size(107, 22);
            this.verwijderenStrings.TabIndex = 13;
            this.verwijderenStrings.Text = "Verwijderen";
            this.verwijderenStrings.UseVisualStyleBackColor = true;
            this.verwijderenStrings.Click += new System.EventHandler(this.verwijderenStrings_Click);
            // 
            // leegmakenStrings
            // 
            this.leegmakenStrings.Location = new System.Drawing.Point(435, 235);
            this.leegmakenStrings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.leegmakenStrings.Name = "leegmakenStrings";
            this.leegmakenStrings.Size = new System.Drawing.Size(107, 22);
            this.leegmakenStrings.TabIndex = 14;
            this.leegmakenStrings.Text = "Leegmaken";
            this.leegmakenStrings.UseVisualStyleBackColor = true;
            this.leegmakenStrings.Click += new System.EventHandler(this.leegmakenStrings_Click);
            // 
            // showListStrings
            // 
            this.showListStrings.Location = new System.Drawing.Point(435, 268);
            this.showListStrings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.showListStrings.Name = "showListStrings";
            this.showListStrings.Size = new System.Drawing.Size(107, 22);
            this.showListStrings.TabIndex = 15;
            this.showListStrings.Text = "Show List";
            this.showListStrings.UseVisualStyleBackColor = true;
            this.showListStrings.Click += new System.EventHandler(this.showListStrings_Click);
            // 
            // SearchStrings
            // 
            this.SearchStrings.Location = new System.Drawing.Point(435, 302);
            this.SearchStrings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SearchStrings.Name = "SearchStrings";
            this.SearchStrings.Size = new System.Drawing.Size(107, 22);
            this.SearchStrings.TabIndex = 16;
            this.SearchStrings.Text = "Search";
            this.SearchStrings.UseVisualStyleBackColor = true;
            this.SearchStrings.Click += new System.EventHandler(this.SearchStrings_Click);
            // 
            // copyStrings
            // 
            this.copyStrings.Location = new System.Drawing.Point(435, 338);
            this.copyStrings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.copyStrings.Name = "copyStrings";
            this.copyStrings.Size = new System.Drawing.Size(107, 22);
            this.copyStrings.TabIndex = 17;
            this.copyStrings.Text = "Copy";
            this.copyStrings.UseVisualStyleBackColor = true;
            this.copyStrings.Click += new System.EventHandler(this.copyStrings_Click);
            // 
            // toevoegenPersoon
            // 
            this.toevoegenPersoon.Location = new System.Drawing.Point(748, 154);
            this.toevoegenPersoon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.toevoegenPersoon.Name = "toevoegenPersoon";
            this.toevoegenPersoon.Size = new System.Drawing.Size(101, 22);
            this.toevoegenPersoon.TabIndex = 18;
            this.toevoegenPersoon.Text = "Toevoegen";
            this.toevoegenPersoon.UseVisualStyleBackColor = true;
            this.toevoegenPersoon.Click += new System.EventHandler(this.toevoegenPersoon_Click);
            // 
            // LeegmakenPersoon
            // 
            this.LeegmakenPersoon.Location = new System.Drawing.Point(748, 227);
            this.LeegmakenPersoon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LeegmakenPersoon.Name = "LeegmakenPersoon";
            this.LeegmakenPersoon.Size = new System.Drawing.Size(101, 22);
            this.LeegmakenPersoon.TabIndex = 19;
            this.LeegmakenPersoon.Text = "Leegmaken";
            this.LeegmakenPersoon.UseVisualStyleBackColor = true;
            this.LeegmakenPersoon.Click += new System.EventHandler(this.LeegmakenPersoon_Click);
            // 
            // verwijderenPersoon
            // 
            this.verwijderenPersoon.Location = new System.Drawing.Point(748, 192);
            this.verwijderenPersoon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.verwijderenPersoon.Name = "verwijderenPersoon";
            this.verwijderenPersoon.Size = new System.Drawing.Size(101, 22);
            this.verwijderenPersoon.TabIndex = 19;
            this.verwijderenPersoon.Text = "Verwijderen";
            this.verwijderenPersoon.UseVisualStyleBackColor = true;
            this.verwijderenPersoon.Click += new System.EventHandler(this.verwijderenPersoon_Click);
            // 
            // showPersonen
            // 
            this.showPersonen.Location = new System.Drawing.Point(748, 260);
            this.showPersonen.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.showPersonen.Name = "showPersonen";
            this.showPersonen.Size = new System.Drawing.Size(101, 22);
            this.showPersonen.TabIndex = 20;
            this.showPersonen.Text = "Show List";
            this.showPersonen.UseVisualStyleBackColor = true;
            this.showPersonen.Click += new System.EventHandler(this.showPersonen_Click);
            // 
            // searchPersoon
            // 
            this.searchPersoon.Location = new System.Drawing.Point(748, 294);
            this.searchPersoon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.searchPersoon.Name = "searchPersoon";
            this.searchPersoon.Size = new System.Drawing.Size(101, 22);
            this.searchPersoon.TabIndex = 21;
            this.searchPersoon.Text = "Search";
            this.searchPersoon.UseVisualStyleBackColor = true;
            this.searchPersoon.Click += new System.EventHandler(this.searchPersoon_Click);
            // 
            // copyPersoon
            // 
            this.copyPersoon.Location = new System.Drawing.Point(748, 330);
            this.copyPersoon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.copyPersoon.Name = "copyPersoon";
            this.copyPersoon.Size = new System.Drawing.Size(101, 22);
            this.copyPersoon.TabIndex = 22;
            this.copyPersoon.Text = "Copy";
            this.copyPersoon.UseVisualStyleBackColor = true;
            this.copyPersoon.Click += new System.EventHandler(this.copyPersoon_Click);
            // 
            // inputleeftijd
            // 
            this.inputleeftijd.Location = new System.Drawing.Point(815, 127);
            this.inputleeftijd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.inputleeftijd.Name = "inputleeftijd";
            this.inputleeftijd.Size = new System.Drawing.Size(110, 23);
            this.inputleeftijd.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(676, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 15);
            this.label4.TabIndex = 24;
            this.label4.Text = "Naam huisdier";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(843, 109);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 15);
            this.label5.TabIndex = 25;
            this.label5.Text = "diersoort";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(54, 381);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 15);
            this.label6.TabIndex = 26;
            this.label6.Text = "Lijst Integers: ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(54, 442);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 15);
            this.label7.TabIndex = 27;
            this.label7.Text = "Lijst huisdieren";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(54, 412);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 15);
            this.label8.TabIndex = 28;
            this.label8.Text = "Lijst strings:";
            // 
            // ListsManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 487);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.inputleeftijd);
            this.Controls.Add(this.copyPersoon);
            this.Controls.Add(this.searchPersoon);
            this.Controls.Add(this.showPersonen);
            this.Controls.Add(this.verwijderenPersoon);
            this.Controls.Add(this.LeegmakenPersoon);
            this.Controls.Add(this.toevoegenPersoon);
            this.Controls.Add(this.copyStrings);
            this.Controls.Add(this.SearchStrings);
            this.Controls.Add(this.showListStrings);
            this.Controls.Add(this.leegmakenStrings);
            this.Controls.Add(this.verwijderenStrings);
            this.Controls.Add(this.toevoegenStrings);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CopyListInteger);
            this.Controls.Add(this.SearchInteger);
            this.Controls.Add(this.showListIntegers);
            this.Controls.Add(this.LeegmakenIntegers);
            this.Controls.Add(this.verwijderenIntegers);
            this.Controls.Add(this.integersToevoegen);
            this.Controls.Add(this.stringsInput);
            this.Controls.Add(this.persoonInput);
            this.Controls.Add(this.integersInput);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ListsManager";
            this.Text = "Stapels";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox integersInput;
        private System.Windows.Forms.TextBox persoonInput;
        private System.Windows.Forms.TextBox stringsInput;
        private System.Windows.Forms.Button integersToevoegen;
        private System.Windows.Forms.Button verwijderenIntegers;
        private System.Windows.Forms.Button LeegmakenIntegers;
        private System.Windows.Forms.Button showListIntegers;
        private System.Windows.Forms.Button SearchInteger;
        private System.Windows.Forms.Button CopyListInteger;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button toevoegenStrings;
        private System.Windows.Forms.Button verwijderenStrings;
        private System.Windows.Forms.Button leegmakenStrings;
        private System.Windows.Forms.Button showListStrings;
        private System.Windows.Forms.Button SearchStrings;
        private System.Windows.Forms.Button copyStrings;
        private System.Windows.Forms.Button toevoegenPersoon;
        private System.Windows.Forms.Button LeegmakenPersoon;
        private System.Windows.Forms.Button verwijderenPersoon;
        private System.Windows.Forms.Button showPersonen;
        private System.Windows.Forms.Button searchPersoon;
        private System.Windows.Forms.Button copyPersoon;
        private System.Windows.Forms.TextBox inputleeftijd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}

